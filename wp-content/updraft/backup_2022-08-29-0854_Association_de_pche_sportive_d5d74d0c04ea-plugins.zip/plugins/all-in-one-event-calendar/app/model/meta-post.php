<?php

/**
 * Post meta entries management.
 *
 * Meta entries management based on {@see Ai1ec_Meta} class.
 *
 * @author     Time.ly Network, Inc.
 * @since      2.0
 * @package    Ai1EC
 * @subpackage Ai1EC.Model
 */
class Ai1ec_Meta_Post extends Ai1ec_Meta {

}