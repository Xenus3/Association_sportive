<?php declare(strict_types = 1);

namespace App\Entities;

use WPSteak\Entities\AbstractPost;

class Timely extends AbstractPost {

	public const POST_TYPE = 'page';
	public const MENU_NAME = 'timely';

}
