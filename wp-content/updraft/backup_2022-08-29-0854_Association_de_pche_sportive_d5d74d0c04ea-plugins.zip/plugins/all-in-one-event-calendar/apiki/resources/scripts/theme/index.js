import '@styles/theme';
import 'airbnb-browser-shims';
// eslint-disable-next-line no-unused-vars
// import config from '@config';

import './vendor/*.js';

// Your code goes here ...
