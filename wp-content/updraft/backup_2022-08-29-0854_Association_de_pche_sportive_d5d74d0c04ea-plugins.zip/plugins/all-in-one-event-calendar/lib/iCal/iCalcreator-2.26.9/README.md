# iCalcreator

is the PHP class package managing

> iCal (rfc2445/rfc5445) calendar information

operating on calendar and
calendar events, reports, todos and journaling data.

~~~~~~~~

iCalcreator supports systems like

* calendars
* CMS
* project management systems
* other applications...

~~~~~~~~

__Builds__

Please review the releaseNotes for a brief overview, 
docs/summary and docs/using for details.

Stable 2.26.9 *(master)*.

Release 2.28 candidate (tag 2.27.17)

Unsupported (tags): 
- 2.26
- 2.24.2
- 2.24
- 2.22.5
